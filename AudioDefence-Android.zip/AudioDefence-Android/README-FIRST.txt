AUDIO DEFENCE FOR ANDROID - READ THIS FIRST

What this is
This folder is the complete Android version of Audio Defence: Zombie Arena, made from the source code of the
Windows port. The game itself (its levels, enemies, weapons, missions, menus and text) is the same code as the
Windows version, translated only where the phone needs something different: the sound engine, speech and the
touch controls. Nothing was added to the game and no levels were invented.

Honest status
It has never been run on a phone. The game's rules and menus were tested on a computer with the phone parts
faked, and the 3D sound engine was tested on its own. The phone parts (sound output, speech, touch, sensors)
have not been tried. Expect the first run to have problems. Tell me exactly what you hear and I will fix it.

An APK cannot be made here, so it has to be built once. The easiest way, with no programming, is GitHub
building it for you in the cloud. It takes about 20 minutes of waiting.

Way 1: let GitHub build it (no Android Studio needed)
This way needs no unzipping and no uploading of many files: you upload ONE file, the zip itself.
1. Make a free account at github.com and sign in.
2. Create a new repository. Any name, for example AudioDefenceAndroid. Private is fine.
3. First add the build instructions. On the repository page choose Add file, then Create new file. In the file
   name box type exactly:  .github/workflows/build.yml
   Then paste the text of build-workflow.txt (it is in this folder, and the same text was given in the chat)
   into the big edit box, and press Commit changes.
4. Then choose Add file, then Upload files, choose the zip file AudioDefence-Android.zip exactly as you
   downloaded it (do not unzip it), and press Commit changes.
5. Open the Actions tab of the repository. A run called "Build the Audio Defence APK" starts by itself.
   If it does not, open it and press Run workflow. Wait until it shows a green tick. That takes about 15 to
   30 minutes the first time.
6. Open the finished run. At the bottom, under Artifacts, download AudioDefence-APK. It is a zip file.
   Unzip it. Inside is app-debug.apk.
7. If the run ends with a red cross, open it, copy the last error lines, and send them to me.

Way 2: with Android Studio (or someone who has it)
Open this folder as a project. Before building, copy the game's data folder (the folder called game from the
Windows port's repository) into app/src/main/assets so that app/src/main/assets/game exists. Press Run, or
use Build, then Build APK.

Putting it on the phone
1. Copy app-debug.apk to the phone, for example by USB cable, email to yourself, or Google Drive.
2. Open it on the phone. Android asks to allow installing from this source: allow it. If Play Protect warns
   that the app is not from the Play Store, choose Install anyway.
3. TURN TALKBACK OFF BEFORE OPENING THE GAME. The game speaks for itself, and TalkBack takes over the
   touches. If TalkBack is on, the game tells you so and asks you to turn it off.
4. The first time, the game unpacks its data. It says so, and then says percentages. This takes a minute or two.
   After that it starts and reads out the opening. Later starts are quick.

Controls (the phone is held sideways; the whole screen is the touch area)
In the menus
  Swipe right, left, up or down: the arrow keys, exactly as on the Windows version. The pair that moves through
      a screen is set by Menu layout in Settings, in the Miscellaneous tab.
  Double tap: press the button (Enter).
  Touch and hold: a row's second action.
  Two-finger tap: go back (Escape).
  Two-finger swipe up or down: first or last item.
  The phone's Back button also goes back.
In a game
  Touch: tap for one shot, keep touching for continuous fire.
  Swipe up: next weapon. Swipe down: reload.
  Melee: tap with three fingers at once, or shake the phone.
      (At the very start, the same three-finger tap skips the intro.)
  Two-finger tap: pause. To skip a line of dialogue in a challenge, pause: Skip dialogue is the first
      button on the pause screen.
  Swipe left or right: turn, when the aiming is set to Swipe.
  Gyro and Tilt aiming use the phone's sensors instead (these are the least tested).
  Two-finger tap: pause.

Releases and the signing key (from version 1.0)
The repository has a secret called SIGNING_KEY holding the project's permanent key (the text of the file
AudioDefence-signing-key.txt). With it, every build is a release called AudioDefence.apk, signed with that
key, and each release installs over the last one with the player's progress kept. Without it, the build is
only a test (app-debug-TEST.apk). Keep a copy of the key file somewhere safe and private: if it is lost, no
later version can ever install over the ones people have, and if someone else gets it, they can make
updates that phones would accept. Whoever takes the project over needs the key file too.
How the app is built is in ci/build.sh, inside the project, so a change to it only needs a new zip.

What is not in yet
Game controllers, vibration, and updating from inside the app (install a newer AudioDefence.apk over the old one instead).

If something goes wrong, tell me what you heard, on which screen, and what you did.

Credits and licence
The Windows port this is made from is by its authors on GitHub (repository lbk2907/AudioDefence-Windows) and
is under the licence in LICENSE-original-port.txt. The game's own sounds and data belong to Somethin' Else and
are not part of this folder; the build downloads them from that public repository. Keep the finished app for
your own use and do not publish it.
