package com.audiodefence.audio;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Pulls the mixer's output on a thread of its own and plays it: 44.1 kHz stereo float, low latency. */
public final class AudioOut implements Runnable {
    private final MiniAl al;
    private AudioTrack track;
    private Thread thread;
    private volatile boolean running;
    private volatile boolean paused;
    private final Object pauseLock = new Object();

    public AudioOut(MiniAl al) {
        this.al = al;
    }

    public void start() {
        int minBytes = AudioTrack.getMinBufferSize(MiniAl.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT);
        int block = MiniAl.BLOCK * 4 * 2;                 // a few blocks of float stereo
        int bytes = Math.max(minBytes, block * 2);
        track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(MiniAl.SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build())
                .setBufferSizeInBytes(bytes)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        running = true;
        track.play();
        thread = new Thread(this, "audio-out");
        thread.setPriority(Thread.MAX_PRIORITY);
        thread.start();
    }

    public void setPaused(boolean p) {
        synchronized (pauseLock) {
            paused = p;
            pauseLock.notifyAll();
        }
        if (track != null) {
            if (p) {
                track.pause();
            } else {
                track.play();
            }
        }
    }

    public void stop() {
        running = false;
        synchronized (pauseLock) {
            pauseLock.notifyAll();
        }
        if (track != null) {
            try {
                track.stop();
            } catch (Exception ignored) {
                // not started
            }
            track.release();
            track = null;
        }
    }

    @Override
    public void run() {
        float[] buf = new float[MiniAl.BLOCK * 2 * 2];
        long lastReport = System.nanoTime();
        long worst = 0;
        while (running) {
            synchronized (pauseLock) {
                while (paused && running) {
                    try {
                        pauseLock.wait();
                    } catch (InterruptedException e) {
                        return;
                    }
                }
            }
            long t0 = System.nanoTime();
            al.render(buf, MiniAl.BLOCK * 2);
            long took = System.nanoTime() - t0;
            worst = Math.max(worst, took);
            AudioTrack t = track;
            if (t == null) {
                return;
            }
            t.write(buf, 0, buf.length, AudioTrack.WRITE_BLOCKING);
            // a phone that cannot keep up: shorten the HRTF filters a little rather than crackle
            long now = System.nanoTime();
            if (now - lastReport > 1_000_000_000L) {
                double budget = (MiniAl.BLOCK * 2) * 1e9 / MiniAl.SAMPLE_RATE;    // ns available per render
                if (worst > budget * 0.8 && al.getTapLimit() > 64) {
                    al.setTapLimit(al.getTapLimit() - 16);
                } else if (worst < budget * 0.3 && al.getTapLimit() < Hrtf.TAPS) {
                    al.setTapLimit(al.getTapLimit() + 8);
                }
                worst = 0;
                lastReport = now;
            }
        }
    }
}
