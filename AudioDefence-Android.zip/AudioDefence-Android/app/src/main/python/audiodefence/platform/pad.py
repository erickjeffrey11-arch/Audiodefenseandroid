"""Game controllers on Android: not supported yet.  This keeps the names the rest of the game imports."""
from __future__ import annotations

PAD_DEFAULTS: dict = {}
PAD_LABELS: dict = {}
NAMES: dict = {}


def set_hints() -> None:
    pass


def family(model) -> str:
    return 'generic'


def button_words(action, mode=None):
    return None


def menu_words(*a, **k):
    return None


def input_name(name, kind=None) -> str:
    return str(name)


class PadMap:
    @classmethod
    def for_model(cls, model):
        return cls()

    def names(self, action):
        return ()

    def text(self, action):
        return ''

    def action_for(self, name):
        return None


class Pads:
    _shared = None

    @classmethod
    def shared(cls) -> 'Pads':
        if cls._shared is None:
            cls._shared = Pads()
        return cls._shared

    def __init__(self):
        self.pads: dict = {}
        self.dualsenses: dict = {}
        self.changed = None
        self.speak = None

    def start(self):
        pass

    def stop(self):
        pass

    def handle(self, event):
        return None

    def connected_models(self):
        return []

    def editing_model(self):
        return None

    def padmap_for(self, source):
        return PadMap()

    def turn(self):
        return 0

    def shaken(self):
        return False

    def can_shake(self, model):
        return False

    def set_triggers(self, *a, **k):
        pass
