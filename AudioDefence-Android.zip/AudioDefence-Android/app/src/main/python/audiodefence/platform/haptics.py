"""Haptics on Android: none yet.  Every call the game makes is accepted and does nothing."""
from __future__ import annotations


class Haptics:
    _shared = None

    @classmethod
    def shared(cls) -> 'Haptics':
        if cls._shared is None:
            cls._shared = Haptics()
        return cls._shared

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return lambda *a, **k: None
