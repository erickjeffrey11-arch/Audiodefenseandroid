#!/usr/bin/env bash
# The build itself, run by .github/workflows/build.yml once Java, Python and Gradle are set up.  It lives in
# the project (and so in the uploaded zip) so that changing how the app is built only takes a new zip.
set -euo pipefail

echo "::group::The game's own data (sounds, levels, playlists) from the Windows and Mac port's public repository"
rm -rf /tmp/adwin
git clone --depth 1 https://github.com/lbk2907/AudioDefence-Windows.git /tmp/adwin \
  || git clone --depth 1 https://github.com/lbk2907/AudioDefence.git /tmp/adwin
mkdir -p app/src/main/assets
rm -rf app/src/main/assets/game
cp -r /tmp/adwin/game app/src/main/assets/game
du -sh app/src/main/assets/game
echo "::endgroup::"

mkdir -p out
if [ -n "${SIGNING_KEY:-}" ]; then
  # the release: signed with the project's permanent key, so each one installs over the last
  printf '%s' "$SIGNING_KEY" | tr -d ' \r\n\t' | base64 -d > /tmp/audiodefence.p12
  export AD_KEYSTORE=/tmp/audiodefence.p12
  trap 'rm -f /tmp/audiodefence.p12' EXIT
  gradle --no-daemon --stacktrace assembleRelease
  cp app/build/outputs/apk/release/app-release.apk out/AudioDefence.apk
  echo "Built out/AudioDefence.apk, the release, signed with the permanent key."
else
  echo "::warning::There is no SIGNING_KEY secret in this repository, so this is only a TEST build (app-debug-TEST.apk). It cannot install over a release, and a release cannot install over it."
  gradle --no-daemon --stacktrace assembleDebug
  cp app/build/outputs/apk/debug/app-debug.apk out/app-debug-TEST.apk
fi
